require 'capybara/cucumber'
require 'selenium-webdriver'
require 'capybara/dsl'
require 'cucumber'
require 'capybara/rspec/matchers'
require 'rspec'
require 'page-object'

World (Capybara::DSL)
World (Capybara::RSpecMatchers)

Capybara.configure do |config|
    config.default_driver = :selenium_chrome
    config.app_host = 'https://dasa.com.br/'
    config.default_max_wait_time = 5
end 